<?php
// This file Makes the DB changes...
global $smcFunc;
$smcFunc['db_insert'](
	'ignore',
	'{db_prefix}settings',
	array('variable' => 'string'),
	array('attachmentDefaultavatar')
	);
?>