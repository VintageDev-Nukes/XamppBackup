[b]Author[/b] : Dragooon
[b]Version[/b] : 1.1.1
[b]Name[/b] : Default Avatar
[b]Tested with[/b] : 1.1.5, 2.0 Beta 3 Public
[hr]

If a user's avatar's field is empty, This mod replaces the avatar with a standard avatar which can be set via Admin > Attachments And Avatars > Avatars.
The avatar URL you set HAVE to be a URL, Not a Path to the image.

The default avatar will appear at every place where the avatar is shown.
[hr]

[size=11pt][b]Changelog[/b][/size]

[b]Version 1.0[/b]
[list]
[li]Initial Release[/li]
[/list]

[b]Version 1.1[/b]
[list]
[li]Took all the changes from templates to Source files[/li]
[li]Now doesn't require any template changes, only sources file and this works with every theme, also it now replaces the avatar everywhere.[/li]
[li]Added support for SMF 2 Beta 3 public[/li]
[/list]

[b]Version 1.1.1[/b]
[list]
[li]Fixed a bug in which user uploaded avatars were not being shown[/li]
[li]Added swedish translation[/li]
[/list]
[hr]

Thank you for using this mod! :)