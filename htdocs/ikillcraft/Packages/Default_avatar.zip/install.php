<?php
// This file Makes the DB changes...
global $db_prefix;
  db_query("INSERT IGNORE INTO {$db_prefix}settings (variable) VALUES ('attachmentDefaultavatar')", __FILE__, __LINE__);
?>